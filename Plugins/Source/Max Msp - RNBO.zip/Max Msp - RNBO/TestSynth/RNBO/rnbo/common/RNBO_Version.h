//automatically generated
#ifndef _RNBO_Version_H_
#define _RNBO_Version_H_
namespace RNBO {
	const char * version = "1.0.2";
}
#endif
