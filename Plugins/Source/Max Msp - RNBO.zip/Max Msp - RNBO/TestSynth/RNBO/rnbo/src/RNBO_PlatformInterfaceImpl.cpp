//
//  PlatformInterfaceImpl.cpp
//
//  Created by Rob Sussman on May 20, 2016
//
//

#include "platforms/stdlib//RNBO_PlatformInterfaceStdLib.h"

namespace RNBO {
	static PlatformInterfaceStdLib platformInstance;
}

