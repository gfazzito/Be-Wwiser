##Duration Parameter

The description of what this parameter does...

**Note**: Additional note goes here...

Units: s <br/>